#!/bin/bash

. ~/$nsfenv/nsf.env

{ echo $apps_pw; echo $sys_pw; echo $web_pw; } | adop phase=apply patchtop=/install.media2/ECC/downloads/ebs patches=30535550
