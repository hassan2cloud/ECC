#!/bin/bash

{ echo apps; echo system; echo weblogic123; } | adop phase=apply patches=21229697 hotpatch=yes workers=32
