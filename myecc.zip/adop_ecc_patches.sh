#!/bin/bash

. ~/.nsf/nsf.env

{ echo $apps_pw; echo $sys_pw; echo $web_pw; } | adop phase=apply patchtop=/install.media2/ECC/downloads/ebs patches=30535540,30535550,30535649,30535647,30535653,31696168,31054002,31713023,31604775,31457942,31132450,31132447,31132464 apply_mode=downtime
