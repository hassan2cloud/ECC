#!/bin/bash
. ~/.nsf/nsf.env

{ echo $apps_pw; echo $sys_pw; echo $web_pw; } | adop phase=apply patchtop=/install.media2/ECC/downloads/ebs patches=30535649,30535653,30535647 apply_mode=downtime 
