#!/bin/bash
. ~/.nsf/nsf.env

{ echo $apps_pw; echo $sys_pw; echo $web_pw; } | adop phase=apply patchtop=/install.media2/ECC/downloads/ebs patches=29499036   apply_mode=downtime
