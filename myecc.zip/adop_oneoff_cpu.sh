#!/bin/bash
. /install.media2/FMLOB_12C/EBS/config/get_pass.env

{ echo $apps_pw; echo $sys_pw; echo $web_pw; } | adop phase=apply patches=31745969,31206584,30980446,30367367,27477203,26282050,29662975 apply_mode=downtime
