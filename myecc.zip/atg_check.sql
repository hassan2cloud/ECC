SELECT codelevel,
decode((codelevel),
'C.9', '12.2.10 Framework Code Stack',
'C.8', '12.2.9 Framework Code Stack',
'C.7', '12.2.7/12.2.8 Framework Code Stack',
'C.6', '12.2.6 Framework Code Stack',
'C.5', '12.2.5 Framework Code Stack',
'C.4', '12.2.4 Framework Code Stack',
'B.5', '12.1.3 Framework Code Stack',
'B.4', '11.5.10 Framework Code Stack') stack
FROM AD_TRACKABLE_ENTITIES
WHERE abbreviation='fwk';
