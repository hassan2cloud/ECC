#!/bin/sh
# Sourcing the environment file
. ~applecc/.nsf/nsf.env
if [ -z "$ECC_BASE" ]; then
    echo "Source the file \$ECC_BASE/Oracle/quickInstall/env/ecc.env before execution of this script"
    exit 1
else
    INIT_FILE="$ECC_BASE/Oracle/quickInstall/env/ecc.env"
    source $INIT_FILE
fi

if [ $? -ne 0 ]; then
    echo "Unable to source $INIT_FILE... Aborting.."
    exit
fi

# Sourcing the property files
. $BIN_BASE/functions.sh


LOGFILE=$ECC_BASE/Oracle/quickInstall/logs/setup.log
#USER_EXISTING=$1
#EBS_DB_SYSTEM_USER=$2
#EBS_DB_SYSTEM_PWD=$3
#ECC_DB_PASSWD=$4
export EBS_DB_SYSTEM_USER=SYSTEM
export EBS_DB_SYSTEM_PWD=$sys_pw
export ECC_DB_PASSWD=$ecc_pw
export ECC_DB_PWD=$ecc_pw
export ECC_DOMAIN_PWD=$web_pw
export ECC_DOMAIN_CONFIRM_PWD=$web_pw
export ECC_DOMAIN_USER=weblogic
export ECC_DB_CONNECTION=FMLOBEBS
echo "Hassan"
echo $USER_EXISTING 
echo $EBS_DB_SYSTEM_USER
echo $EBS_DB_SYSTEM_PWD
echo $ECC_DB_PASSWD
ECC_DB_CONFIRM_PASSWD=$ecc_pw

	#printf "Do you have existing database schema for database object [y/n]?";
export ECC_DB_URL=FMLOBEBS
	HAS_ECC_USER=n
		CUSTOM_DB_SYSTEM_USERNAME=$EBS_DB_SYSTEM_USER
		CUSTOM_DB_PASSWORD=$EBS_DB_SYSTEM_PWD
     	        ECC_DB_CONFIRM_PWD=$ECC_DB_CONFIRM_PASSWD

			echo "Creating $ECC_DB_USER..."
			sqlplus -s /nolog <<-EOFI
			WHENEVER OSERROR EXIT 9;
			WHENEVER SQLERROR EXIT SQL.SQLCODE;
			connect  system/SySTE0202M_2021PTX@FMLOBEBS
			set head off 
			set verify off 
			set feedback off 
			set pages 0 
			@$SQL_BASE/createDBUsers.sql;
			EOFI


			sql_error_code=$?                                                                                                                        
			if [ $sql_error_code != 0 ]                                                                   
				then                                                                                           
				echo "The user creating script failed. Please refer to the $ECC_BASE/Oracle/quickInstall/logs/setup.log for more information"     
				echo "Error code $sql_error_code"                                                             
				exit 1;                                                                                        
			fi 

                                                                                          
			echo "$ECC_DB_USER user created successfully"
				
			echo "Creating $ECC_DB_USER schema..."


			sqlplus -s /nolog <<-EOFJ>> ${LOGFILE}
			WHENEVER OSERROR EXIT 9;
			WHENEVER SQLERROR EXIT SQL.SQLCODE;
			connect $ECC_DB_USER/"$ECC_DB_PWD"@"$ECC_DB_CONNECTION"
			@$SQL_BASE/ecc_schema.sql $SQL_BASE; 
			EOFJ

                        sql_return_code=$?                                                                                                                                
			if [ $sql_return_code != 0 ]                                                                   
				then                                                                                           
				echo "The schema script failed. Please refer to the $ECC_BASE/Oracle/quickInstall/logs/setup.log for more information"     
				echo "Error code $sql_return_code"                                                             
				exit 1;                                                                                        
			fi                                                                                    
			echo "$ECC_DB_USER schema created successfully" 
			exit 0
		
