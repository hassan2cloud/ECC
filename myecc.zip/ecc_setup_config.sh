#!/bin/bash



cp /ecc02/oracle/ECC/Oracle/quickInstall/scripts/createUsersInCustomDB.sh /ecc02/oracle/ECC/Oracle/quickInstall/scripts/createUsersInCustomDB.sh.orig
cp createUsersInCustomDB.sh /ecc02/oracle/ECC/Oracle/quickInstall/scripts/createUsersInCustomDB.sh 
sh nsfenvSetup.sh
cp /ecc02/oracle/ECC/Oracle/quickInstall/scripts/createUsersInCustomDB.sh.orig /ecc02/oracle/ECC/Oracle/quickInstall/scripts/createUsersInCustomDB.sh
