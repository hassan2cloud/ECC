#!/bin/sh
#
# This script configures the EBS Information Discovery components and connects to Oracle E-Business Suite instance


if [ -f "./EccConfig.properties" ]; then
        EccConfig_path=`pwd`
else
        read -p "Enter the absolute full path of EccConfig.properties file: " CONFIG_PROPERTIES
        EccConfig_path=`echo $CONFIG_PROPERTIES | sed "s|\(.*\)/EccConfig.properties|\1|"`
fi
ecc_base_path_orig=`cat $EccConfig_path/EccConfig.properties | grep "^ECC_BASE" | cut -d= -f2`
ecc_base_path=`cat $EccConfig_path/EccConfig.properties | grep "^ECC_BASE" | cut -d= -f2 | sed "s|\(.*\)/$|\1|"`
if [ "$EccConfig_path" = "$ecc_base_path/Oracle/quickInstall" ]; then
    if [ "$ecc_base_path_orig" != "$ecc_base_path" ]; then
        sed -i "s|ECC_BASE=$ecc_base_path_orig|ECC_BASE=$ecc_base_path|" $EccConfig_path/EccConfig.properties
    fi
    continue;
else
    printf "\n\nERROR: The ECC_BASE configured in $EccConfig_path/EccConfig.properties is $ecc_base_path_orig.\n\nHowever, $EccConfig_path/EccConfig.properties is the one used for execution of this script.\n\nPlease double-check the ECC_BASE in $EccConfig_path/EccConfig.properties and re-execute the script from \$QI_BASE\n\n.. Aborting..\n\n"
    exit 1
fi
# Sourcing the initialization script
        INIT_FILE="$EccConfig_path/initializeEnv.sh"
echo -e "Initialized file is $INIT_FILE"
source $INIT_FILE $EccConfig_path/EccConfig.properties

if [ "$?" -ne 0 ]; then
    echo "Unable to source $INIT_FILE... Aborting.."
    exit
fi
# Done

#Creating environment file
sh $EccConfig_path/createEnvFile.sh $EccConfig_path
. $EccConfig_path/bin/functions.sh
ENV_FILE=$EccConfig_path/env/ecc.env
source $ENV_FILE
echo -e "\nEnvironemnt file is $ENV_FILE and QI_BASE is $QI_BASE"
c="y"

while [ "$c" == "y" ]
do
    echo -e "\n\nSelect which option you want to proceed with\n\n
             1. Database Setup\n\n
	     2. Install Weblogic Server\n\n
             3. Create ECC Domain\n\n
	     4. Create EBS JNDI\n\n
	     5. Integrate ECC with EBS\n\n
             6. Exit:\n" | tee -a $LOG_FILE


    read PHASESELECTED 
    echo $PHASESELECTED >>  $LOG_FILE

    case "$PHASESELECTED" in
        1)  if [ -z "$ECC_DB_URL" ]; then
		printf "\nConfigure the ECC_DB_URL - the url to connect to ECC schema):"
	    else
                echo -e ""
                echo -e "Selected ECC DB is $ECC_DB_URL"
                echo -e ""
		$QI_BASE/scripts/createUsersInCustomDB.sh
	    $QI_BASE/wlsScripts/installWeblogic.sh $ENV_FILE | tee -a $LOG_FILE
           cp $QI_SOFTWARE/weblogic/com.bea.core.utils.classloaders.jar $WL_HOME/modules/
           cp $QI_SOFTWARE/weblogic/wljmsra.rar $WL_HOME/server/lib/
           read -s ECC_DB_PWD
	   if [ -n "$ECC_DB_PWD" ]; then
           read -s ECC_DOMAIN_PWD
          read -s ECC_DOMAIN_CONFIRM_PWD
          $QI_BASE/wlsScripts/createEccDomain.sh "$ENV_FILE" "$ECC_DOMAIN_USER" "$ECC_DOMAIN_PWD" "$ECC_DB_USER" "$ECC_DB_PWD" | tee -a $LOG_FILE
				if [ "$?" == "0" ]; then
		                        sh $ECC_BASE/Oracle/quickInstall/wlsScripts/startEccManagedServer.sh $ENV_FILE "$ECC_DOMAIN_USER" "$ECC_DOMAIN_PWD" | tee -a $LOG_FILE
					if [ "$?" == "0" ]; then
						sh $ECC_BASE/Oracle/quickInstall/importApplication.sh "" "$LOG_FILE"
					else
						printf "\nECC Managed Server start failed"
					fi
                		        printf "\nConfigured the ECC domain successfully." | tee -a $LOG_FILE
	                        	break
        	            	else
                	        	echo -e "\nCreation of ECC Domain failed. Hence aborting" | tee -a $LOG
	                        	return 1
 	                        fi
                           else
                           fi
                       fi
                       printf "\n"
                       attempt=`expr $attempt + 1`
                   done
                else
                        echo -e "ECC database user password should not be empty"
               fi

	   ;;
	4) echo "Creating JNDI ...."
           . $BIN_BASE/createJndi.sh | tee -a $LOG_FILE
           ;;
	5)  echo -e "Proceed with Integration? confirm(y) otherwise(n): " | tee -a $LOG_FILE
            read  TOPROCEED
            echo $TOPROCEED >> $LOG_FILE
            if [ "$TOPROCEED" == "y" -o "$TOPROCEED" == "Y" ]; then
	   	if [ -z "$ECC_DB_PWD" ]; then
                printf "\nEnter the password for ECC DB user $ECC_DB_USER :"
                read -s ECC_DB_PWD
           	fi
		if [ -z "$ECC_DOMAIN_PWD" ]; then
		printf "\nEnter the password for ECC admin user $ECC_DOMAIN_USER :"
		read -s ECC_DOMAIN_PWD
		fi
	   	if [ -n "$ECC_DB_PWD" ]; then
                   . $QI_BASE/integrateEBSSecurity.sh $ENV_FILE $ECC_DB_PWD $ECC_DOMAIN_PWD | tee -a $LOG_FILE
 			if [ "$?" -eq "0" ]
			       then
				sqlplus -S ${ECC_DB_USER}/${ECC_DB_PWD}@"${ECC_DB_CONNECTION}" @$SQL_BASE/ecc_srcsysUrlUpdate.sql 'ebsdb' 'EBS' ${EBS_MIDDLETIER_PROTOCOL}://${EBS_MIDDLETIER_HOST_FQDN}:${EBS_MIDDLETIER_PORT}
			fi
		fi
            else
                echo -e "\nExiting set up to allow manual changes (Profile and Proxy settings) at EBS end or validating ECC components" | tee -a $LOG_FILE
            fi
            c="n"
            ;;
        6) c="n"
           ;;
        *) echo "Wrong Phase selected"
           c="n"
           ;;
    esac
done
