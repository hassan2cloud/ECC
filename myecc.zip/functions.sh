#!/bin/sh

# Sourcing the environment file
if [ -z "$ECC_BASE" ]; then
    echo "Source the file \$ECC_BASE/Oracle/quickInstall/env/ecc.env before execution of this script"
    exit 1
else
    INIT_FILE="$ECC_BASE/Oracle/quickInstall/env/ecc.env"
    source $INIT_FILE
fi

if [ $? -ne 0 ]; then
    echo "Unable to source $INIT_FILE... Aborting.."
    exit
fi

source $QI_BASE/constants.properties


message()
{
   echo -e "\n[$(date +'%Y-%m-%dT%H:%M:%S%z')]: $1"
}

#cd -
#This functions requires two mandatory parameters
# 1. Process Name and 2. Process Display name
f_is_server_up()
{
	if [[ $# -eq 2 ]] ; then
		PROCESS_NAME=$1
		PROCESS_DISPLAY_NAME=$2
		WL_HOME_ABS=`readlink -f "${WL_HOME}"`
		PROCESS=`ps aux | grep "\-Dweblogic.Name=$PROCESS_NAME" | grep "\-Dwls.home=${WL_HOME_ABS}/server" | grep -v grep | grep java | wc -l`
		if [ "$PROCESS" -gt "0" ]; then
        	        echo "SUCCESSFUL: $PROCESS_DISPLAY_NAME is up"
                	return 0
	        else
        	        echo "ERROR: $PROCESS_DISPLAY_NAME is down"
                	return 1
	       	fi
	else
	    	echo 'ERROR: is_java_process_up function requires two mandatory parameters:Process Name and Process Display name'
    		exit 1
	fi
}

#The following function is to set the value for a given property in a property file
set_if_not_empty()
{
  file_name=$1
  property=$2
  value=$3

  if [ -f "$file_name" ]; then

      if [ -z "$value" ]; then
            sed -i "s:#\?$property=.*:#$property=$value:" $file_name
      else
            sed -i "s:#\?$property=.*:$property=$value:" $file_name
      fi
      return 0
  else
      echo -e "ERROR: The file $file_name  does not exist to set the property $property\n" 	
      exit 1
  fi
}

#The following function is to validate if the XE database is up.
f_is_info_disc_database_up()
{
	if [[ $# -eq 1 ]] ; then
		echo -e "Connecting to $1 DB"
	    	if echo "exit;" | sqlplus / as sysdba@$1  2>&1 | grep -q "Connected to"
		then 
		    echo "SUCCESSFUL: Database connected OK"
		    return 0
		else
		    echo "ERROR: Database Connection FAIL"
		    return 1
		fi				
	else
	    echo "ERROR: ORACLE SID needs to be passed as parameter"
	    return 2
	fi
}

f_is_custom_disc_database_up()
{
	DB_USERNAME=`f_get_property_in_file $SCRIPTS_BASE/customDbDetails.properties "$CUSTOM_DB_USERNAME_KEY"`
	DB_PWD=`f_get_property_in_file $SCRIPTS_BASE/customDbDetails.properties "$CUSTOM_DB_PWD_KEY"`
	CUSTOM_DB_URL=$(echo "$INTEGRATOR_STUDIO_DB_URL" | sed "s|jdbc:oracle:thin:@\(.*\)|\1|" | sed "s|\(.*\):\(.*\)$|\1\/\2|")
	f_is_database_up "$CUSTOM_DB_URL" "$DB_USERNAME" "$DB_PWD"
}

#The following function is to validate if the EBS database is up.
f_is_ebs_database_up() 
{
	EBS_DB_URL=$DB_URL
	EBS_DB_PASSWORD=$1
	if [[ $# -eq 1 ]] ; then
		f_is_database_up "$EBS_DB_URL" $EBS_DB_USERNAME $EBS_DB_PASSWORDa
		return $?
	else
            echo "EBS DB password needs to be passed as parameter for user $EBS_DB_USERNAME"
            return 2
	fi
}

#The following function is to validate if the EBS database is up.
f_is_ecc_database_up()
{
        ECC_DB_URL=$ECC_DB_CONNECTION
        ECC_DB_PASSWORD=$1
        if [[ $# -eq 1 ]] ; then
                f_is_database_up "$ECC_DB_URL" $ECC_DB_USERNAME $ECC_DB_PASSWORD
		return $?
        else
            echo "ECC DB password needs to be passed as parameter for user $ECC_DB_USERNAME"
            return 2
        fi
}


#----------------------------------------------------------------------------------
# Function: check_db
# Parameters : DB Connection URL
# This function is to check if the database connectivity exists
#---------------------------------------------------------------------------------
function check_db {
  CONNECTION=$1
  DB_USERNAME=$2
  DB_PWD=$3
  RETVAL=`sqlplus -silent $DB_USERNAME/$DB_PWD@"$CONNECTION" <<EOF
SET PAGESIZE 0 FEEDBACK OFF VERIFY OFF HEADING OFF ECHO OFF
SELECT 'Alive' FROM dual;
EXIT;
EOF`
  if [ -z "$RETVAL" ]; then
     echo "NA"
     return 0
  fi
  if [ "$RETVAL" == "Alive" ]; then
    echo $RETVAL
    return 0
  else
    echo ""
    return 1
  fi

}

#The following function is to validate if the database is up
f_is_database_up()
{
        if [[ $# -eq 3 ]] ; then
		DB_URL=$1
		DB_USER=$2
		DB_PASSWORD=$3
		
		check_db_value=`check_db "$DB_URL" "$DB_USER" "$DB_PASSWORD"`
		if [ -n "$check_db_value" ] && [ "$check_db_value" == "Alive" ]
		then
                    return 0
                else
                    echo -e "\nERROR: Database Connection FAIL\n"
                    return 1
                fi
        else
            echo "The function f_is_database_up expects three parameters DB url , DB username and DB password"
            return 2
        fi
}


#The function is_info_disc_listener_up is to validate if the information discoveyr listener is up
f_is_ecc_listener_up()
{
	lsnrctl status  | grep "Connection refused" > /dev/null
	if [ $? -eq 0 ]; then
		echo -e "\nWARNING: DB Listener is down\n"
		return 1
	else
		echo "SUCCESSFUL: DB Listener is up"
		return 0
	fi
}

#This function getEidConfigProperties is to retrieve the properties from $QI_BASE/EidConfig.properties
f_getEccConfigProperties()
{
	echo -e "**The EccConfigProperties are as follows:**"
	cat $QI_BASE/EccConfig.properties | grep -v "^#" | sed '/^$/d'
	echo -e "** EccConfig properties end **"
}

f_get_ecc_profile()
{
	if [[ $# -eq 2 ]] ; then
                f_get_profile_option $1 $2 $FND_ECC_URL_KEY
		return $?
        else
                echo "f_get_ecc_profile expects two parameters 1) EBS APPS username 2) EBS APPS password"
		return 2
        fi

}
f_get_server_sec_profile()
{
	if [[ $# -eq 2 ]] ; then
                f_get_profile_option $1 $2 $FND_SERVER_SEC_KEY
		return $?
        else
                echo "f_get_server_sec_profile expects two parameters 1) EBS APPS username 2) EBS APPS password"
		return 2
        fi

}

f_get_server_ip_sec_profile()
{
	if [[ $# -eq 2 ]] ; then
                f_get_profile_option $1 $2 $FND_SERVER_IP_SEC_KEY
		return $?
        else
                echo "f_get_server_ip_sec_profile expects two parameters 1) EBS APPS username 2) EBS APPS password"
		return 2
        fi

}

f_get_server_desktop_profile()
{
        if [[ $# -eq 2 ]] ; then
                f_get_profile_option $1 $2 $FND_SERVER_DESKTOP_USER_KEY
		return $?
        else
                echo "ERROR: f_get_server_desktop_profile expects two parameters 1) EBS APPS username 2) EBS APPS password"
		return 2
        fi

}

f_get_profile_option_temp()
{
        if [[ $# -eq 3 ]] ; then
                EBS_DB_USERNAME=$1
                EBS_DB_PASSWORD=$2
		PROFILE_OPTION_NAME=$3
		#echo "Profile option $PROFILE_OPTION_NAME $EBS_DB_USERNAME@$DB_URL"
VALUE=`sqlplus -silent $EBS_DB_USERNAME/$EBS_DB_PASSWORD@"$DB_URL" <<END
set pagesize 0 feedback off verify off heading off echo off
select POV.PROFILE_OPTION_VALUE from FND_PROFILE_OPTIONS PO,FND_PROFILE_OPTION_VALUES POV where PO.PROFILE_OPTION_ID=POV.PROFILE_OPTION_ID and PROFILE_OPTION_NAME='$PROFILE_OPTION_NAME' ;
exit;
END`
		echo "$PROFILE_OPTION_NAME=$VALUE"
		return 0
	else
                echo -e "ERROR: f_get_profile_option expects three parameters 1) EBS APPS username 2) EBS APPS password 3) PROFILE_OPTION_NAME"
		return 2
        fi

}

#The function f_get_profile_option retrieves the profile option value from the lookup table for the profile option.
f_get_profile_option()
{
        if [[ $# -eq 3 ]] ; then
                EBS_DB_USERNAME=$1
                EBS_DB_PASSWORD=$2
                PROFILE_OPTION_NAME=$3
                #echo "Profile option $PROFILE_OPTION_NAME $EBS_DB_USERNAME@$DB_URL"
VALUE=`sqlplus -silent $EBS_DB_USERNAME/$EBS_DB_PASSWORD@"$DB_URL" <<END
set pagesize 0 feedback off verify off heading off echo off
select POV.PROFILE_OPTION_VALUE from FND_PROFILE_OPTIONS PO,FND_PROFILE_OPTION_VALUES POV where PO.PROFILE_OPTION_ID=POV.PROFILE_OPTION_ID and PROFILE_OPTION_NAME='$PROFILE_OPTION_NAME' ;
exit;
END`
            if [ -z $VALUE ]; then
		echo ""
		return 1
	    else 	
		echo "$VALUE"
		return 0
	    fi
        else
                echo "f_get_profile_option expects three parameters 1) EBS APPS username 2) EBS APPS password 3) PROFILE_OPTION_NAME"
		return 2
        fi

}

f_check_node_exists()
{
	if [[ $# -eq 3 ]] ; then
	    EBS_DB_USERNAME=$1
            EBS_DB_PASSWORD=$2
            NODE_NAME=`echo "$3" | tr [a-z] [A-Z]`
VALUE=`sqlplus -silent $EBS_DB_USERNAME/$EBS_DB_PASSWORD@"$DB_URL" <<END
set pagesize 0 feedback off verify off heading off echo off
select count(1) from FND_NODES where NODE_NAME='$NODE_NAME';
exit;
END`
	    if [ "$VALUE" -gt 0 ]; then
		echo "SUCCESSFUL: Node $NODE_NAME is registered in EBS"
		return 0
	    else
		echo "WARNING: Node $NODE_NAME is registered in EBS"
		return 1
	    fi
	else
		echo "f_check_node_exists expects three parameters 1) EBS APPS username 2) EBS APPS password 3) NODE_NAME"
		return 2
	fi
}

#This function f_check_fnd_vault validates if clover credentials are appropriately put in FND_VAULT
f_check_fnd_vault()
{
	if [[ $# -eq 4 ]] ; then
	    EBS_DB_USERNAME=$1
            EBS_DB_PASSWORD=$2
	    CLOVER_USER=$3
	    CLOVER_PWD=$4
	    VALUE=`sqlplus -silent $EBS_DB_USERNAME/"$PASSWORD"@\'"$DB_URL"\' @$SQL_BASE/f_check_fnd_vault.sql $CLOVER_USER $CLOVER_PWD`
	    CHECK_STATUS=`echo $VALUE | sed "s|.*CHECK_STATUS_START:\(.*\):CHECK_STATUS_END.*|\1|"`
	    echo $CHECK_STATUS
	    echo "$CHECK_STATUS" | grep "validated successfully" > /dev/null
	    return $?
	else
		echo "f_check_fnd_vault expects four parameters 1) EBS APPS username 2) EBS APPS password 3) Clover application user name 4) Clover application password"
		return 2
	fi
}

#This function f_check_portal_properties_exist verifies the existence of portal_ext.properties
f_check_solr_properties_exist()
{
	if [ -f $DOMAIN_HOME/solr.properties ]; then
                echo -e "File $DOMAIN_HOME/solr.properties available"
		return 0
        else
                echo -e "File $DOMAIN_HOME/solr.properties missing"
		return 1
        fi
}

#This function f_check_portal_properties_exist verifies the existence of portal_ext.properties
f_check_ecc_config_properties_exist()
{
        if [ -f $DOMAIN_HOME/ecc_config.properties ]; then
                echo -e "File $DOMAIN_HOME/ecc_config.properties available"
                return 0
        else
                echo -e "File $DOMAIN_HOME/ecc_config.properties missing"
                return 1
        fi
}


#This function f_check_property_in_file verifies the property value from a file(which can be sourced).
#This function expects three parameters
#<PARAM 1> - Property File location
#<PARAM 2> - Property
#<PARAM 3> - Expected value
f_check_property_in_file()
{
	if [[ $# -eq 3 ]]; then
		SOURCE_FILE=$1
		PROPERTY=$2
		EXPECTED_VALUE=$3
		VALUE=`f_get_property_in_file $SOURCE_FILE $PROPERTY`
		f_log_message_property_check_in_file $? $SOURCE_FILE $PROPERTY $EXPECTED_VALUE $VALUE
	fi
}

f_get_property_in_file()
{
        if [[ $# -eq 2 ]]; then
                SOURCE_FILE=$1
                PROPERTY=$2
#                VALUE=`cat $SOURCE_FILE | grep "^[ ]*$PROPERTY" | tr -s " " | cut -d= -f2`
		VALUE=`cat $SOURCE_FILE | grep "^[ ]*$PROPERTY" | tr -s " " | sed "s|^[ ]*$PROPERTY=\(.*\)|\1|"`
		if [ "$VALUE" = "" ]; then
		    echo ""
                    return 2
                else
		    echo "$VALUE"
		    return 0
		fi
			
	else
                echo -e "The function f_get_property_in_file expects three parameters Property File location,Property"
                return 1
        fi

}

#This function f_check_property_in_file is used to log messages
f_log_message_property_check_in_file()
{
	RET_CODE=$1
	SOURCE_FILE=$2
	PROPERTY=$3
	EXPECTED_VALUE=$4
	VALUE=$5
	if [ $RET_CODE -eq 2 ]; then
            echo -e "ERROR: Property \"$PROPERTY\" is either empty or not available in $SOURCE_FILE"
        else
            if [ $RET_CODE -eq 0 ]; then
		if [ "$VALUE" = "$EXPECTED_VALUE" ]; then	
                	echo -e "SUCCESSFUL: Property \"$PROPERTY\" is $VALUE in $SOURCE_FILE and match successful"
		else
		    	echo -e "WARNING: Property \"$PROPERTY\" is $VALUE in $SOURCE_FILE but expected value is $EXPECTED_VALUE"
		fi
            fi
        fi

}

#This function prints the QI Build version
f_print_qi_build_version()
{
	echo "$QI_BUILD_VERSION"
}

#This function is to start the managed servers
f_start_managed_server()
{
    if [ $# -eq 5 ]; then
	ADMIN_SERVER_URL=$1
	ADMIN_SERVER_USER=$2
	ADMIN_SERVER_PWD=$3
	MANAGED_SERVER_NAME=$4
	LOG_FILE=$5
	#!/bin/sh

dirPath=$ECC_SERVER_DOMAIN/servers/$MANAGED_SERVER_NAME/security

if [ ! -d "$dirPath" ]; then
        mkdir -p $dirPath
fi

#if [ ! -f "$dirPath"/boot.properties ]; then
        touch $dirPath/boot.properties
        echo "username=$ADMIN_SERVER_USER">$dirPath/boot.properties
        echo "password=$ADMIN_SERVER_PWD">>$dirPath/boot.properties
#fi
echo "Starting the $MANAGED_SERVER_NAME ..."
    cd $ECC_SERVER_DOMAIN/bin
    touch $LOG_FILE
    nohup ./startManagedWebLogic.sh $MANAGED_SERVER_NAME $ADMIN_SERVER_URL > $LOG_FILE 2>&1 &

LOGPATH=$ECC_SERVER_DOMAIN/bin/$LOG_FILE
status_code=0
x=1
while :
do
    managed_server_process=`ps -ef | grep $MANAGED_SERVER_NAME | grep java | wc -l`
    if [ "$managed_server_process" -gt 0 ]
    then

        if grep -Rq "Server state changed to RUNNING" $LOGPATH
        then
            echo -e "Started the $MANAGED_SERVER_NAME successfully\n"
            status_code=0 
	    break
        fi

        sleep 1
        x=$(( $x + 1 ))

        if grep -Rq "Server state changed to FORCE_SHUTTING_DOWN" $LOGPATH
        then
                echo -e "The $MANAGED_SERVER_NAME failed to start properly! For details, please check log file at $LOGPATH\n"
                status_code=1
		break
        fi
    fi
    if [ $x -eq 300  ]
    then
        echo -e "$MANAGED_SERVER_NAME is taking much time to start? you can force close by hitting Ctrl + C or check log file at $LOGPATH\n"
    fi
done
rm $dirPath/boot.properties
return $status_code
    else
	echo -e "\nTo execute the function f_start_managed_server following parameters are needed:\n"
	echo -e "1. ADMIN_SERVER_URL\n"
	echo -e "2. ADMIN_SERVER_USERNAME\n"
	echo -e "3. ADMIN_SERVER_PASSWORD\n"
	echo -e "4. MANAGED_SERVER_NAME\n"
	echo -e "5. MANAGED SERVER Log file name\n"	
        return 1
    fi
}
