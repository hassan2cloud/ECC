sh nsf_ecc_install.sh
sh nsf_eccconfig.sh
sh nsfenvSetup.sh
