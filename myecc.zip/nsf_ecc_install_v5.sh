#!/bin/ksh

. ~applecc/ecc.env

echo $ECC_BASE

export log_dir=/install.media2/FMLOB_12C/EBS/logs
> $log_dir/ecc_install.log

log_message()
{
message_text=${1}
message_type=${2}

case ${message_type} in
   E) message_text="Error: "${message_text}
   ;;
   M) message_text="Emergency: "${message_text}
   ;;
   W) message_text="Warning: "${message_text}
   ;;
   *)
   ;;
esac

echo $(date '+%D %H:%M:%S') ${message_text} | tee -a ${log_dir}/ecc_install.log
}


if [ -d /ecc01/oracle/ECC ]
then
 log_message "ECC directory exist" "G"
else
mkdir -p /ecc01/oracle/ECC
 log_message "ECC BASE directory created"
fi



 log_message "Checking for ecc download file" "G"
if [ -f "$ECC_STAGE/downloads/p30535681_R12_GENERIC.zip" ]
then
cd $ECC_STAGE/stage
unzip -o $ECC_STAGE/downloads/p30535681_R12_GENERIC.zip
else
log_message "ECC file does not exists" "E"
exit
fi

log_message "Copying bsx files to ECC_BASE: located at:"$ECC_BASE
for x in `ls *bsx`
do
cp -f $x $ECC_BASE
done

chmod +x $ECC_BASE/*.bsx
echo $?

cd $ECC_BASE
for f in *.bsx; do sh $f; done
log_message "Install complete"
