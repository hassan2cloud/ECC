#!/bin/bash

. ~/.nsf/nsf.env


for x in `cat ebs_patchlist.txt`
do
applied_status=`sqlplus -s apps/$apps_pw << CHKPATCHES
set head off
set verify off
set feedback off
Select bug_id from ad_bugs where bug_number in '$x';
CHKPATCHES`

if [ -z $applied_status ]
then
echo "Patch ==> "$x" has not APPLIED"
else
echo "Patch ==> "$x" APPLIED"
fi 


done
