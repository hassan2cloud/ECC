#!/bin/bash

. ~/ecc.env

if [ -d /ecc01/oracle/ECC ]
then
echo "ECC directory exist"
cp -p $ECC_BASE/Oracle/quickInstall/EccConfig.properties $ECC_BASE/Oracle/quickInstall/EccConfig.properties.orig
cp $ECC_STAGE/downloads/EccConfig.properties  $ECC_BASE/Oracle/quickInstall/
else
mkdir -p /ecc01/oracle/ECC
echo "ECC BASE directory create"
fi
