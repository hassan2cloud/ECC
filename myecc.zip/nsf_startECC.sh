#!/bin/bash

. ~/.nsf/nsf.env
echo "Check if up"
#cd $ECC_BASE/Oracle/quickInstall/bin
{ echo 1; } | sh ./start.sh
