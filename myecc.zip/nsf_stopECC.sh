#!/bin/bash


. ~/.sbx/nsf.env
. $ECC_BASE/Oracle/quickInstall/env/ecc.env
#export ECC_PWD=`echo $web_pw`
echo "Check if up"
#cd $ECC_BASE/Oracle/quickInstall/bin
{ echo 1; } | ./stop.sh
