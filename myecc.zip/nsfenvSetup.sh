#!/bin/sh
#
# This script configures the EBS Information Discovery components and connects to Oracle E-Business Suite instance
export log_dir=/install.media2/FMLOB_12C/EBS/logs
> $log_dir/ecc_install.log


log_message()
{
message_text=${1}
message_type=${2}

case ${message_type} in
   E) message_text="Error: "${message_text}
   ;;
   M) message_text="Emergency: "${message_text}
   ;;
   W) message_text="Warning: "${message_text}
   ;;
   *)
   ;;
esac

echo $(date '+%D %H:%M:%S') ${message_text} | tee -a ${log_dir}/ecc_install.log
}

	if [ -f  ~/.nsf/nsf.env ]
	then
	echo "Automation check passed"
	log_message "Automation check passed" "I"
	else
	log_message "Automation check Failed" "E"
	exit
	fi

	if [[ ${ECC_BASE:-notset} = 'notset' ]]
	then
   	log_message "ECC BASE Environment has not been set" "E"
   	exit 1
	fi

	if [[ ${ECC_STAGE:-notset} = 'notset' ]]
	then
   	log_message "ECC STAGE Environment has not been set" "E"
   	exit 1
	fi

. ~/.nsf/nsf.env
export EBS_DB_SYSTEM_USER=SYSTEM
export EBS_DB_SYSTEM_PWD=$sys_pw
export ECC_DB_PASSWD=$ecc_pw
export ECC_DB_PWD="ECC/"$ecc_pw
export ECC_DOMAIN_PWD=$web_pw
export ECC_DOMAIN_CONFIRM_PWD=$web_pw
export ECC_DOMAIN_USER=weblogic


EccConfig_path=/ecc02/oracle/ECC/Oracle/quickInstall
ecc_base_path_orig=`cat $EccConfig_path/EccConfig.properties | grep "^ECC_BASE" | cut -d= -f2`
echo $ecc_base_path_orig
ecc_base_path=`cat $EccConfig_path/EccConfig.properties | grep "^ECC_BASE" | cut -d= -f2 | sed "s|\(.*\)/$|\1|"`
echo $ECC_BASE
if [ "$EccConfig_path" = "$ecc_base_path/Oracle/quickInstall" ]; then
    log_message "ECC Config Check" "M"
    if [ "$ecc_base_path_orig" != "$ecc_base_path" ]; then
        sed -i "s|ECC_BASE=$ecc_base_path_orig|ECC_BASE=$ecc_base_path|" $EccConfig_path/EccConfig.properties
    log_message "ECC Config Check" "M"
    fi
fi
    log_message "Sourcing the initialization script"
INIT_FILE="$EccConfig_path/initializeEnv.sh"
echo -e "Initialized file is $INIT_FILE"
source $INIT_FILE $EccConfig_path/EccConfig.properties
if [ "$?" -ne 0 ]; then
    echo "Unable to source $INIT_FILE... Aborting.."
    log_message "Unable to source $INIT_FILE... Aborting.."
    exit
fi
# Done

#Creating environment file
cd $EccConfig_path
sh $EccConfig_path/createEnvFile.sh $EccConfig_path
sh $EccConfig_path/bin/functions.sh
ls $EccConfig_path/bin/functions.sh
ENV_FILE=$EccConfig_path/env/ecc.env
source $ENV_FILE
echo -e "\nEnvironemnt file is $ENV_FILE and QI_BASE is $QI_BASE"
echo "Creating ECC scheam in the Database"
sh $QI_BASE/scripts/createUsersInCustomDB.sh
sh $QI_BASE/wlsScripts/installWeblogic.sh $ENV_FILE | tee -a $LOG_FILE
cp $QI_SOFTWARE/weblogic/com.bea.core.utils.classloaders.jar $WL_HOME/modules/
cp $QI_SOFTWARE/weblogic/wljmsra.rar $WL_HOME/server/lib/
sh $QI_BASE/wlsScripts/createEccDomain.sh "$ENV_FILE" "$ECC_DOMAIN_USER" "$ECC_DOMAIN_PWD" "$ECC_DB_USER" "$ECC_DB_PWD" | tee -a $LOG_FILE
sh $ECC_BASE/Oracle/quickInstall/wlsScripts/startEccManagedServer.sh $ENV_FILE "$ECC_DOMAIN_USER" "$ECC_DOMAIN_PWD" | tee -a $LOG_FILE
sh $ECC_BASE/Oracle/quickInstall/wlsScripts/startEccManagedServer.sh $ENV_FILE "$ECC_DOMAIN_USER" "$ECC_DOMAIN_PWD" | tee -a $LOG_FILE
sh $ECC_BASE/Oracle/quickInstall/importApplication.sh "" "$LOG_FILE"
