#!/bin/ksh

ohs_inst_loc=`grep -i s_ohs_instance_loc $CONTEXT_FILE`
ohs_comp=`grep -i s_ohs_component $CONTEXT_FILE`

echo $ohs_inst_loc
echo $ohs_comp
