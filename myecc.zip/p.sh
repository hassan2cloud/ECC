java -jar /install.media2/ECC/downloads/6880880/opatch_generic.jar -silent oracle_home=/ecc01/oracle/ECC/Oracle/Middleware
