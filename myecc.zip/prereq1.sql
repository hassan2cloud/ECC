select * from ad_bugs where bug_number in '26834480'
/
