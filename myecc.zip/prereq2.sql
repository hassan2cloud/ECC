select * from ad_bugs where bug_number in '28840844'
/
