#!/bin/sh

# Sourcing the environment file
if [ -z "$ECC_BASE" ]; then
    echo "Source the file \$ECC_BASE/Oracle/quickInstall/env/ecc.env before execution of this script"
    exit 1
else
    INIT_FILE="$ECC_BASE/Oracle/quickInstall/env/ecc.env"
    source $INIT_FILE
fi

if [ $? -ne 0 ]; then
    echo "Unable to source $INIT_FILE... Aborting.."
    exit
fi
. $QI_BASE/bin/functions.sh
ECC_PWD=`echo $web_pw`

c="y"

while [ "$c" == "y" ]
   do
      echo -e "\nSelect ECC Component you want to stop\n\n
      1. All \n \n
      2. ECC Managed Server \n \n
      3. ECC Domain Admin Server \n \n
      4. Exit:\n  "

      read SELECTED
      case "$SELECTED" in
         1) printf "\nEnter password for ECC domain admin user $ECC_DOMAIN_USER : "
            read -s $ECC_PWD
	    echo -e ""
	    $QI_BASE/wlsScripts/stopAllServers.sh $INIT_FILE $ECC_DOMAIN_USER $ECC_PWD
	    echo "Done"
	    ;;	
	2) if [ "x$ECC_PWD" = "x" ]; then
               printf "\nEnter password for ECC domain admin user $ECC_DOMAIN_USER : "
               read -s ECC_PWD
	   fi
	    echo -e ""
	   $QI_BASE/wlsScripts/stopEccManagedServer.sh $INIT_FILE $ECC_DOMAIN_USER $ECC_PWD
           echo "Done"
           ;;

	3) if [ "x$ECC_PWD" = "x" ]; then
               printf "\nEnter password for ECC domain admin user $ECC_DOMAIN_USER : "
               read -s ECC_PWD
           fi
	    echo -e ""
	   $QI_BASE/wlsScripts/stopEccAdminServer.sh $INIT_FILE $ECC_DOMAIN_USER $ECC_PWD
           echo "Done"
           ;;
	*) echo -e "\n Exiting"
	   c="n"
	   ;;
   esac
   done

