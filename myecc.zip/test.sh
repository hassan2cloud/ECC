

if [ -d /ecc01/oracle/ECC ]
then
echo "ECC directory exist"
else
#mkdir -p /ecc01/oracle/ECC
echo "ECC BASE directory create"
fi
