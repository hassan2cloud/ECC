#!/bin/bash

opatch version
echo $?

for x in `cat weblogic_patches.txt`
do
opatch lsinventory |grep $x
done
