#!/bin/bash


cd $ECC_STAGE/downloads
for x in `cat weblogic_patches.txt`
do
cd $ECC_STAGE/downloads/$x
opatch apply |grep $x
done
